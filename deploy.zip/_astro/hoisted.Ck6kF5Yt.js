import{g as e}from"./hoisted.DjaCmHkL.js";e.set(".line",{yPercent:115});e.to(".line",{yPercent:0,duration:1.1,ease:"power4.out",stagger:.09,delay:.2});
